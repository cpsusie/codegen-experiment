﻿using System;

namespace ContentsLibrary
{
    public sealed class TestClass
    {
        public string MyText { get; }
        public string? Maybe { get; }

        public TestClass(string text, string? maybe)
        {
            MyText = text ?? throw new ArgumentNullException(nameof(text));
            Maybe = maybe;
        }
    }
}
